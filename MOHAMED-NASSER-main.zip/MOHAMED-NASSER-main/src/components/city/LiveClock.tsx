import { useEffect, useState } from "react";

const AR_DAYS = ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];

export function useCityClock() {
  const [now, setNow] = useState<Date | null>(null);

  useEffect(() => {
    setNow(new Date());
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  if (!now) return { time: "--:--", day: "", phase: "الليلة", hour: 21 };

  const hour = now.getHours();
  const time = new Intl.DateTimeFormat("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  }).format(now);
  const phase =
    hour < 5
      ? "آخر الليل"
      : hour < 12
        ? "الصباح"
        : hour < 17
          ? "العصر"
          : hour < 20
            ? "المغرب"
            : "الليلة";

  return { time, day: AR_DAYS[now.getDay()]!, phase, hour };
}

export function LiveClock({ className = "" }: { className?: string }) {
  const { time, day, phase } = useCityClock();
  return (
    <span className={`inline-flex items-baseline gap-2 text-sm font-medium ${className}`}>
      <span className="font-mono font-bold text-slate-800 tabular-nums">{time}</span>
      <span className="text-slate-500">
        {day} · {phase}
      </span>
    </span>
  );
}
