import { useEffect } from "react";

import type { Moment } from "@/data/cities";
import { EnergyMeter } from "./EnergyMeter";
import { EventImage } from "./EventImage";

export function MomentSheet({ moment, onClose }: { moment: Moment | null; onClose: () => void }) {
  useEffect(() => {
    if (!moment) return undefined;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [moment, onClose]);

  if (!moment) return null;

  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center sm:items-center">
      <button
        aria-label="إغلاق"
        onClick={onClose}
        className="absolute inset-0 bg-slate-900/30 backdrop-blur-xs transition-opacity"
      />
      <article
        key={moment.id}
        className="animate-reveal relative m-5 w-full max-w-md overflow-hidden rounded-2xl border border-slate-200/90 bg-white shadow-2xl sm:m-6"
      >
        {/* Real Event Photo Header */}
        <div className="relative aspect-16/9 w-full overflow-hidden bg-slate-100">
          <EventImage
            moment={moment}
            className="size-full"
            imageClassName="size-full object-cover"
            alt={moment.title}
          />
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/30" />
          <div className="absolute top-3.5 inset-x-3.5 flex items-center justify-between gap-3">
            <span className="rounded-full bg-white/95 px-3 py-0.5 text-xs font-bold text-slate-900 shadow-xs backdrop-blur-xs">
              {moment.window}
            </span>
            <button
              onClick={onClose}
              className="rounded-full bg-black/40 px-2.5 py-0.5 text-xs font-semibold text-white backdrop-blur-xs transition-colors hover:bg-black/60"
            >
              إغلاق ✕
            </button>
          </div>
          <div className="pointer-events-none absolute bottom-3 start-4 end-4 flex items-center justify-between text-xs font-semibold text-white drop-shadow-xs">
            <span className="rounded-md bg-black/40 px-2 py-0.5 backdrop-blur-xs">
              {moment.place}
            </span>
            <span className="rounded-md bg-black/40 px-2 py-0.5 backdrop-blur-xs">
              {moment.district}
            </span>
          </div>
        </div>

        <div className="p-6">
          <h3 className="font-display text-xl font-black text-slate-900 leading-snug">
            {moment.title}
          </h3>
          <p className="mt-1.5 font-mono text-xs font-medium text-slate-500">
            {moment.place} · {moment.district} · {moment.distanceKm} كم · {moment.price}
          </p>
          <p className="mt-3 text-sm leading-relaxed text-slate-600">{moment.note}</p>

          <div className="mt-4 border-t border-slate-100 pt-3">
            <EnergyMeter value={moment.energy} crowd={moment.crowd} />
          </div>

          <div className="mt-4 flex flex-wrap gap-1.5">
            {moment.tags.map((t) => (
              <span
                key={t}
                className="rounded-full border border-slate-200 bg-slate-50 px-2.5 py-0.5 text-xs font-medium text-slate-600"
              >
                {t}
              </span>
            ))}
          </div>
        </div>
      </article>
    </div>
  );
}
