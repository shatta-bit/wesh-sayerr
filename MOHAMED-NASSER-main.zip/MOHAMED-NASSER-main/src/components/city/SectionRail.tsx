import { SECTIONS, type SectionKey } from "@/data/cities";

export function SectionRail({
  value,
  onChange,
  counts,
}: {
  value: SectionKey;
  onChange: (k: SectionKey) => void;
  counts: Record<SectionKey, number>;
}) {
  return (
    <nav
      aria-label="أقسام المدينة"
      className="flex w-full min-w-0 max-w-full snap-x gap-2 overflow-x-auto pb-2 sm:flex-wrap sm:overflow-visible [scrollbar-width:none] [-webkit-overflow-scrolling:touch]"
    >
      {SECTIONS.map((s) => {
        const active = s.key === value;
        return (
          <button
            key={s.key}
            onClick={() => onChange(s.key)}
            aria-current={active}
            className={[
              "group flex shrink-0 snap-start items-center gap-2 rounded-xl border px-4 py-2.5 transition-all duration-200 shadow-2xs",
              active
                ? "border-emerald-600 bg-emerald-600 font-bold text-white shadow-xs"
                : "border-slate-200/90 bg-white text-slate-700 hover:border-slate-300 hover:bg-slate-50 hover:text-slate-900",
            ].join(" ")}
          >
            <span className="text-base leading-none">{s.emoji}</span>
            <span className="text-sm">{s.label}</span>
            <span
              className={[
                "rounded-full px-2 py-0.5 font-mono text-xs font-semibold transition-colors",
                active ? "bg-white/20 text-white" : "bg-slate-100 text-slate-600",
              ].join(" ")}
            >
              {counts[s.key] ?? 0}
            </span>
          </button>
        );
      })}
    </nav>
  );
}
