import { PHASES, type PhaseKey } from "@/lib/phases";

export function PhaseDial({
  value,
  onChange,
}: {
  value: PhaseKey;
  onChange: (k: PhaseKey) => void;
}) {
  return (
    <div className="inline-flex items-center gap-1 rounded-full border border-slate-200/90 bg-white p-1 shadow-xs">
      {PHASES.map((p) => {
        const active = p.key === value;
        return (
          <button
            key={p.key}
            onClick={() => onChange(p.key)}
            aria-pressed={active}
            title={p.label}
            className={[
              "rounded-full px-3 py-1 text-xs font-medium transition-all duration-200",
              active
                ? "bg-emerald-600 font-semibold text-white shadow-xs"
                : "text-slate-600 hover:bg-slate-100 hover:text-slate-900",
            ].join(" ")}
          >
            {p.short}
          </button>
        );
      })}
    </div>
  );
}
