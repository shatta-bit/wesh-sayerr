import { Radio } from "lucide-react";
import { socialLinks } from "../../config/social";
import { CITIES } from "../../data/cities";

interface FooterProps {
  currentCitySlug?: string;
  onCitySelect?: (slug: string) => void;
  showCitySwitcher?: boolean;
}

export function Footer({ currentCitySlug, onCitySelect, showCitySwitcher = true }: FooterProps) {
  const socialChannels = [
    {
      id: "whatsapp",
      name: "واتساب",
      url: socialLinks.whatsappUrl,
      icon: (
        <svg className="size-5" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
        </svg>
      ),
    },
    {
      id: "facebook",
      name: "فيسبوك",
      url: socialLinks.facebookUrl,
      icon: (
        <svg className="size-5" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
          <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
        </svg>
      ),
    },
    {
      id: "instagram",
      name: "إنستغرام",
      url: socialLinks.instagramUrl,
      icon: (
        <svg
          className="size-5"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          aria-hidden="true"
        >
          <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
          <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
          <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
        </svg>
      ),
    },
    {
      id: "x",
      name: "إكس (تويتر)",
      url: socialLinks.xUrl,
      icon: (
        <svg className="size-5" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
          <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
        </svg>
      ),
    },
  ];

  return (
    <footer className="border-t border-slate-200/80 bg-white py-10 text-xs text-slate-500">
      <div className="mx-auto max-w-7xl px-5 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-8 md:flex-row md:items-center md:justify-between">
          {/* Brand Info */}
          <div className="flex flex-col items-start gap-2">
            <div className="flex items-center gap-2">
              <span className="flex size-7 items-center justify-center rounded-lg bg-emerald-100 text-emerald-700">
                <Radio className="size-4" />
              </span>
              <span className="font-display text-base font-bold text-slate-900">وش صاير</span>
              <span className="rounded-full bg-emerald-50 px-2 py-0.5 font-mono text-[11px] font-bold text-emerald-700">
                مباشر
              </span>
            </div>
            <p className="text-xs text-slate-500">
              المنصة السعودية الذكية لاكتشاف نبض وطاقة وتجارب المدن في هذه اللحظة.
            </p>
          </div>

          {/* Social Channels Strip */}
          <div className="flex flex-col items-start gap-2.5 sm:items-end">
            <span className="font-display text-xs font-semibold text-slate-700">
              تابع وش صاير على منصات التواصل
            </span>
            <div className="flex items-center gap-2.5">
              {socialChannels.map((channel) => (
                <a
                  key={channel.id}
                  href={channel.url || "#"}
                  target={channel.url ? "_blank" : undefined}
                  rel={channel.url ? "noopener noreferrer" : undefined}
                  aria-label={channel.name}
                  title={channel.name}
                  onClick={(e) => {
                    if (!channel.url) {
                      e.preventDefault();
                    }
                  }}
                  className="flex size-11 items-center justify-center rounded-xl border border-slate-200/90 bg-white text-slate-600 shadow-2xs transition-all duration-200 hover:-translate-y-0.5 hover:border-emerald-400 hover:bg-emerald-50 hover:text-emerald-700 hover:shadow-xs active:scale-95"
                >
                  {channel.icon}
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* City Switcher in Footer (if enabled) */}
        {showCitySwitcher && (
          <div className="mt-8 flex flex-wrap items-center justify-between gap-4 border-t border-slate-100 pt-6">
            <div className="flex items-center gap-2 text-slate-400">
              <span>المدن المتاحة:</span>
            </div>
            <div className="flex flex-wrap items-center gap-2 sm:gap-4">
              {CITIES.map((c) => (
                <button
                  key={c.slug}
                  onClick={() => {
                    if (onCitySelect) {
                      onCitySelect(c.slug);
                    }
                    window.scrollTo({ top: 0, behavior: "smooth" });
                  }}
                  className={[
                    "rounded-lg px-2.5 py-1 text-xs transition-colors",
                    c.slug === currentCitySlug
                      ? "bg-emerald-50 font-bold text-emerald-800"
                      : "text-slate-500 hover:bg-slate-50 hover:text-slate-900",
                  ].join(" ")}
                >
                  {c.name}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Copyright */}
        <div className="mt-6 border-t border-slate-100 pt-6 text-center text-slate-400">
          <p>
            جميع الحقوق محفوظة © {new Date().getFullYear()} وش صاير · صُمم بعناية لعشاق استكشاف
            المدن السعودية
          </p>
        </div>
      </div>
    </footer>
  );
}
