import { useMemo } from "react";

import { SECTIONS, type City, type Moment, type SectionKey } from "@/data/cities";
import { CityMapLayer } from "./CityMapLayer";

const EMOJI: Record<SectionKey, string> = SECTIONS.reduce(
  (acc, s) => ({ ...acc, [s.key]: s.emoji }),
  {} as Record<SectionKey, string>,
);

function hash(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) h = (h ^ s.charCodeAt(i)) * 16777619;
  return Math.abs(h);
}

/** deterministic pseudo-position so the "map" is stable between renders */
function posOf(mm: Moment): { x: number; y: number } {
  const h = hash(mm.id);
  return { x: 8 + ((h % 1000) / 1000) * 84, y: 10 + (((h >> 10) % 1000) / 1000) * 78 };
}

export function PulseMap({
  city,
  section,
  selectedId,
  onSelect,
}: {
  city: City;
  section: SectionKey | "all";
  selectedId: string | null;
  onSelect: (mm: Moment) => void;
}) {
  const points = useMemo(() => city.moments.map((mm) => ({ mm, ...posOf(mm) })), [city]);

  return (
    <div className="relative aspect-[4/3] w-full overflow-hidden rounded-2xl border border-slate-200/90 bg-white shadow-sm sm:aspect-[16/9]">
      <CityMapLayer intensity={0.7} />

      <div className="pointer-events-none absolute inset-x-0 top-0 h-16 overflow-hidden opacity-25">
        <span className="animate-scan block h-4 w-full bg-gradient-to-b from-transparent via-emerald-500/40 to-transparent" />
      </div>

      {points.map(({ mm, x, y }, i) => {
        const dim = section !== "all" && mm.section !== section;
        const active = selectedId === mm.id;
        return (
          <button
            key={mm.id}
            onClick={() => onSelect(mm)}
            aria-label={mm.title}
            className={[
              "group animate-float-slow absolute -translate-x-1/2 -translate-y-1/2",
              "transition-opacity duration-500",
              dim ? "opacity-30 hover:opacity-75" : "opacity-100",
            ].join(" ")}
            style={{
              insetInlineStart: `${x}%`,
              top: `${y}%`,
              animationDelay: `${(i % 7) * 0.7}s`,
              animationDuration: `${8 + (i % 5)}s`,
            }}
          >
            <span className="relative flex size-7 items-center justify-center">
              <span
                className="animate-ripple absolute inset-0 rounded-full border border-emerald-500/40"
                style={{
                  animationDelay: `${(i % 5) * 0.5}s`,
                }}
              />
              <span
                className={[
                  "relative flex size-7 items-center justify-center rounded-full border text-xs transition-all duration-300 shadow-2xs",
                  active
                    ? "scale-125 border-emerald-600 bg-emerald-100 text-emerald-900 font-bold"
                    : "border-slate-200 bg-white group-hover:scale-115 group-hover:border-emerald-500",
                ].join(" ")}
              >
                {EMOJI[mm.section]}
              </span>
            </span>
            <span className="pointer-events-none absolute start-1/2 top-full mt-1.5 -translate-x-1/2 rounded-md border border-slate-200 bg-white px-2 py-0.5 text-[11px] font-semibold whitespace-nowrap text-slate-700 opacity-0 shadow-xs transition-opacity duration-200 group-hover:opacity-100">
              {mm.district} · {mm.energy}%
            </span>
          </button>
        );
      })}

      <p className="pointer-events-none absolute bottom-3 start-4 rounded-full border border-slate-200/80 bg-white/90 px-3 py-1 text-xs font-semibold text-slate-600 shadow-2xs backdrop-blur-xs">
        {city.name} · {city.moments.length} نقطة نشاط
      </p>
    </div>
  );
}
