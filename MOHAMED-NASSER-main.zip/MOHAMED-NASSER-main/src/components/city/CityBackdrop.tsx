import { CityMapLayer } from "./CityMapLayer";

/** Light city backdrop: abstract street map, faint architectural blocks, subtle emerald pulse. */
export function CityBackdrop({ dense = false }: { dense?: boolean }) {
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
      <CityMapLayer intensity={dense ? 0.9 : 0.65} />

      <svg
        className="absolute inset-0 h-full w-full opacity-[0.25]"
        viewBox="0 0 800 600"
        preserveAspectRatio="xMidYMid slice"
      >
        {[
          [180, 120],
          [540, 330],
          [180, 480],
          [540, 120],
        ].map(([x, y], i) => (
          <circle
            key={i}
            cx={x}
            cy={y}
            r="4"
            className="fill-emerald-600 animate-pulse-dot"
            style={{ animationDelay: `${i * 0.45}s` }}
          />
        ))}
      </svg>

      <div className="absolute inset-x-0 bottom-0 h-48 bg-gradient-to-t from-white via-white/80 to-transparent" />
    </div>
  );
}
