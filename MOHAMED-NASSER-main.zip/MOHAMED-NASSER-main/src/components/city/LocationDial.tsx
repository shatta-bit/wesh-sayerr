import { CITIES } from "@/data/cities";

/** location control: clean light signal selector with switchable city coordinates */
export function LocationDial({
  value,
  onChange,
  compact = false,
}: {
  value: string;
  onChange: (slug: string) => void;
  compact?: boolean;
}) {
  return (
    <div
      className={[
        "inline-flex max-w-full min-w-0 items-center gap-2 rounded-full border border-slate-200/90 bg-white/90 shadow-xs backdrop-blur-xs",
        compact ? "px-2.5 py-1" : "px-3 py-1.5",
      ].join(" ")}
    >
      <span className="flex shrink-0 items-center gap-1.5 font-mono text-[10px] font-medium tracking-wider text-slate-500">
        <span className="animate-pulse-dot inline-block size-1.5 rounded-full bg-emerald-600" />
        المدينة
      </span>
      <span className="h-3.5 w-px shrink-0 bg-slate-200" />
      <div className="flex min-w-0 flex-1 items-center gap-1 overflow-x-auto [scrollbar-width:none] [-webkit-overflow-scrolling:touch]">
        {CITIES.map((c) => {
          const active = c.slug === value;
          return (
            <button
              key={c.slug}
              onClick={() => onChange(c.slug)}
              aria-pressed={active}
              className={[
                "relative shrink-0 rounded-full font-medium transition-all duration-200",
                compact ? "px-2.5 py-0.5 text-[11px]" : "px-2.5 sm:px-3 py-1 text-xs",
                active
                  ? "bg-emerald-50 font-bold text-emerald-700 shadow-2xs"
                  : "text-slate-600 hover:bg-slate-100 hover:text-slate-900",
              ].join(" ")}
            >
              {c.nickname}
            </button>
          );
        })}
      </div>
    </div>
  );
}
