import { useState } from "react";
import { MapPin, Image as ImageIcon, ExternalLink } from "lucide-react";
import type { Moment } from "@/data/cities";
import { usePlacePhoto } from "@/hooks/usePlacePhoto";

interface EventImageProps {
  moment: Moment;
  cityName?: string;
  className?: string;
  imageClassName?: string;
  showAttribution?: boolean;
  alt?: string;
}

export function EventImage({
  moment,
  cityName,
  className = "",
  imageClassName = "size-full object-cover",
  showAttribution = true,
  alt,
}: EventImageProps) {
  const { photo, loading } = usePlacePhoto(moment, cityName);
  const [imageLoaded, setImageLoaded] = useState(false);
  const [imageError, setImageError] = useState(false);

  const displayAlt = alt || `${moment.title} - ${moment.place}، ${moment.district}`;

  // Neutral clean placeholder when no verified photo is available or load fails
  if (!loading && (imageError || !photo?.url || photo?.isPlaceholder)) {
    return (
      <div
        className={`relative flex flex-col items-center justify-center overflow-hidden border border-slate-200/80 bg-gradient-to-b from-slate-50 to-slate-100/90 text-slate-400 p-4 text-center select-none ${className}`}
      >
        {/* Subtle geometric architectural pattern */}
        <div className="absolute inset-0 opacity-[0.03] bg-[radial-gradient(#0f172a_1px,transparent_1px)] [background-size:12px_12px]" />

        <div className="relative z-10 flex flex-col items-center gap-1.5">
          <div className="flex size-9 items-center justify-center rounded-full border border-slate-200/80 bg-white/90 text-emerald-600 shadow-2xs">
            <MapPin className="size-4.5" />
          </div>
          <span className="max-w-[85%] truncate font-display text-xs font-bold text-slate-700">
            {moment.place}
          </span>
          <span className="font-mono text-[11px] text-slate-400">
            {moment.district} {cityName ? `· ${cityName}` : ""}
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className={`relative overflow-hidden bg-slate-100 ${className}`}>
      {/* Loading Skeleton */}
      {(!imageLoaded || loading) && (
        <div className="absolute inset-0 z-10 flex animate-pulse items-center justify-center bg-slate-100">
          <ImageIcon className="size-6 text-slate-300" />
        </div>
      )}

      {/* Real-world Venue Photograph */}
      {photo?.url && (
        <img
          src={photo.url}
          alt={displayAlt}
          referrerPolicy="no-referrer"
          loading="lazy"
          onLoad={() => setImageLoaded(true)}
          onError={() => setImageError(true)}
          className={`${imageClassName} transition-opacity duration-300 ${
            imageLoaded ? "opacity-100" : "opacity-0"
          }`}
        />
      )}

      {/* Verified Google Places / Venue Attribution Overlay */}
      {showAttribution && photo?.attribution?.name && imageLoaded && (
        <div className="pointer-events-none absolute bottom-1.5 start-1.5 z-20 flex max-w-[85%] items-center gap-1 rounded bg-black/45 px-1.5 py-0.5 text-[9px] font-medium text-white/90 backdrop-blur-xs">
          <span className="truncate">
            {photo.source === "google_places" ? "📍 Google Places: " : "📷 "}
            {photo.attribution.name}
          </span>
          {photo.attribution.uri && (
            <a
              href={photo.attribution.uri}
              target="_blank"
              rel="noopener noreferrer"
              className="pointer-events-auto shrink-0 opacity-80 transition-opacity hover:opacity-100"
              title="عرض المصدر"
            >
              <ExternalLink className="size-2.5" />
            </a>
          )}
        </div>
      )}
    </div>
  );
}
