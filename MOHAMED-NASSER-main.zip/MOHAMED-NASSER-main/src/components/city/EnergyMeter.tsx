export function EnergyMeter({ value, crowd }: { value: number; crowd: string }) {
  const bars = 5;
  const filled = Math.max(1, Math.round((value / 100) * bars));
  return (
    <div className="flex items-center gap-2">
      <div className="flex items-end gap-[3px]" aria-hidden>
        {Array.from({ length: bars }).map((_, i) => (
          <span
            key={i}
            className={[
              "w-[3px] rounded-full transition-all duration-500",
              i < filled ? "bg-emerald-600" : "bg-slate-200",
            ].join(" ")}
            style={{ height: `${6 + i * 3}px`, transitionDelay: `${i * 45}ms` }}
          />
        ))}
      </div>
      <span className="font-mono text-xs font-medium tracking-wide text-slate-500">
        {crowd} · {value}%
      </span>
    </div>
  );
}
