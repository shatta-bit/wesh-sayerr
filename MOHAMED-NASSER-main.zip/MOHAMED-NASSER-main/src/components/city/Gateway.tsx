import { useState } from "react";

/** The gateway: signage dial to enter the live city */
export function Gateway({
  liveCount,
  phaseLabel,
  onEnter,
}: {
  liveCount: number;
  phaseLabel: string;
  onEnter: () => void;
}) {
  const [opening, setOpening] = useState(false);

  function push() {
    if (opening) return;
    setOpening(true);
    window.setTimeout(onEnter, 780);
  }

  return (
    <div className="relative w-fit">
      {opening && (
        <span
          aria-hidden
          className="animate-gate pointer-events-none absolute start-1/2 top-1/2 -z-0 size-28 -translate-x-1/2 -translate-y-1/2 rounded-full"
          style={{
            background: "rgba(22, 163, 74, 0.25)",
          }}
        />
      )}

      <button
        onClick={push}
        aria-label="وش صاير الحين؟"
        className="group relative flex items-center gap-4 rounded-3xl border border-slate-200/90 bg-white/95 p-3 pe-8 shadow-lg shadow-slate-200/50 transition-all duration-300 hover:border-emerald-500/50 hover:shadow-xl hover:shadow-emerald-500/10 active:scale-[0.985] backdrop-blur-xs"
      >
        <span className="relative flex size-16 shrink-0 items-center justify-center sm:size-20">
          <span
            aria-hidden
            className="animate-ripple absolute inset-0 rounded-full border border-emerald-500/40"
          />
          <span
            aria-hidden
            className="absolute inset-0 rounded-full border border-dashed border-emerald-300/60 transition-transform duration-[9000ms] group-hover:rotate-180"
          />
          <span className="relative flex size-12 items-center justify-center rounded-full bg-emerald-600 font-display text-xl font-bold text-white shadow-md shadow-emerald-600/30 transition-transform duration-300 group-hover:scale-105 sm:size-14 sm:text-2xl">
            ؟
          </span>
        </span>

        <span className="text-start">
          <span className="block text-xs font-semibold uppercase tracking-wider text-emerald-700">
            {phaseLabel}
          </span>
          <span className="mt-1 block font-display text-2xl font-black text-slate-900 sm:text-3xl">
            وش صاير الحين؟
          </span>
          <span className="mt-1.5 block text-xs font-medium text-slate-500">
            {opening ? "ندخلك المدينة..." : `${liveCount} نقطة نشاط تنتظرك · اضغط للاستكشاف`}
          </span>
        </span>
      </button>
    </div>
  );
}
