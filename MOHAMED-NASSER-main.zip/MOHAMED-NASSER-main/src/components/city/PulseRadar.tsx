import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import type { City } from "@/data/cities";
import { CityMapLayer } from "./CityMapLayer";
import {
  RADAR_CATEGORIES,
  buildRadar,
  radarLine,
  radarStatus,
  radarTiming,
  type RadarPoint,
} from "@/lib/radar";

type Stage = "veil" | "scan" | "focus" | "found";

const VEIL_LINES = ["خلّنا نشوف...", "وش صاير في المدينة؟"];

/** one full beam rotation, in ms — the whole sequence is timed off this */
const BEAM_MS = 4200;

/** Signature interaction: an abstract city pulse radar that scans, then picks one thing for you. */
export function PulseRadar({
  city,
  phaseLabel,
  onClose,
  onSeeAll,
}: {
  city: City;
  phaseLabel: string;
  onClose: () => void;
  onSeeAll: () => void;
}) {
  const points = useMemo(() => buildRadar(city).sort((a, b) => a.beamDeg - b.beamDeg), [city]);
  const [run, setRun] = useState(0);
  const [stage, setStage] = useState<Stage>("veil");
  const [line, setLine] = useState(0);
  const [revealed, setRevealed] = useState(0);
  const [pickId, setPickId] = useState<string | null>(null);
  const excluded = useRef<string[]>([]);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const drag = useRef<{ x: number; y: number; id: number; moved: boolean } | null>(null);
  const lens = useRef<HTMLDivElement>(null);
  const resultRef = useRef<HTMLDivElement>(null);

  /* scripted sequence: two lines, progressive blips, then one pick */
  useEffect(() => {
    const timers: number[] = [];
    setStage("veil");
    setLine(0);
    setRevealed(0);
    setPickId(null);
    timers.push(window.setTimeout(() => setLine(1), 900));
    timers.push(
      window.setTimeout(() => {
        setStage("scan");
        const total = points.length;
        const steps = [0.3, 0.55, 0.78, 0.92, 1];
        steps.forEach((f, i) =>
          timers.push(
            window.setTimeout(
              () => setRevealed(Math.max(1, Math.round(total * f))),
              200 + i * (BEAM_MS / 5),
            ),
          ),
        );
      }, 1700),
    );
    timers.push(
      window.setTimeout(
        () => {
          const fresh = points.filter((p) => !excluded.current.includes(p.id));
          const base = fresh.length ? fresh : points;
          const pool = base.filter((p) => p.moment.energy > 45);
          const list = pool.length ? pool : base;
          const p = list[Math.floor(Math.random() * list.length)];
          if (p) {
            excluded.current = [...excluded.current, p.id].slice(-Math.max(1, points.length - 1));
            setPickId(p.id);
            setOffset({ x: p.x * 0.55, y: p.y * 0.55 });
            setStage("focus");
            timers.push(window.setTimeout(() => setStage("found"), 1250));
          }
        },
        1700 + BEAM_MS + 300,
      ),
    );
    return () => timers.forEach(window.clearTimeout);
  }, [run, points]);

  const rescan = useCallback(() => {
    setStage("veil");
    setPickId(null);
    window.setTimeout(() => setRun((r) => r + 1), 260);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  /* drag to wander the field */
  const onPointerDown = (e: React.PointerEvent) => {
    drag.current = { x: e.clientX, y: e.clientY, id: e.pointerId, moved: false };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };
  const onPointerMove = (e: React.PointerEvent) => {
    const d = drag.current;
    if (!d || d.id !== e.pointerId) return;
    const size = lens.current?.clientWidth ?? 320;
    const dx = (e.clientX - d.x) / (size / 2);
    const dy = (e.clientY - d.y) / (size / 2);
    if (Math.abs(e.clientX - d.x) + Math.abs(e.clientY - d.y) > 6) d.moved = true;
    drag.current = { ...d, x: e.clientX, y: e.clientY };
    setOffset((o) => ({
      x: Math.max(-1.2, Math.min(1.2, o.x - dx)),
      y: Math.max(-1.2, Math.min(1.2, o.y - dy)),
    }));
  };
  const onPointerUp = () => {
    drag.current = null;
  };

  const picked = points.find((p) => p.id === pickId) ?? null;

  /* make sure the discovery result is actually on screen on short phones */
  useEffect(() => {
    if (stage !== "found") return;
    const t = window.setTimeout(
      () => resultRef.current?.scrollIntoView({ behavior: "smooth", block: "end" }),
      140,
    );
    return () => window.clearTimeout(t);
  }, [stage, pickId]);
  const visible = stage === "veil" ? 0 : revealed;
  const counter = stage === "veil" ? 0 : Math.max(1, visible);
  const locked = stage === "focus" || stage === "found";
  /* beam slows down once it locks onto a point */
  const beamDuration = locked ? `${(BEAM_MS * 3) / 1000}s` : `${BEAM_MS / 1000}s`;
  const counterLine =
    locked && visible >= points.length
      ? `${city.liveCount} شيء صاير الآن`
      : visible >= points.length
        ? `${counter} شيء`
        : `${counter} شيء حولك`;

  function selectPoint(p: RadarPoint) {
    if (drag.current?.moved) return;
    setPickId(p.id);
    setStage("found");
  }

  return (
    <div className="animate-veil fixed inset-0 z-50 flex flex-col bg-white/95 backdrop-blur-md">
      <CityMapLayer intensity={0.5} />

      <header className="relative flex items-center justify-between px-6 pt-6 sm:px-10">
        <p className="flex items-center gap-2 text-xs font-semibold tracking-wider text-slate-700">
          <span className="animate-pulse-dot inline-block size-2 rounded-full bg-emerald-600" />
          <span className="font-bold text-emerald-700">LIVE</span> · الآن · {city.name}
        </p>
        <button
          onClick={onClose}
          className="rounded-full border border-slate-200 bg-white px-3 py-1 text-xs font-semibold text-slate-600 shadow-2xs transition-colors hover:bg-slate-50 hover:text-slate-900"
        >
          إغلاق ✕
        </button>
      </header>

      <div className="relative flex flex-1 flex-col items-center justify-center overflow-y-auto overscroll-contain px-4 pb-10">
        {stage === "veil" ? (
          <p
            key={line}
            className="animate-reveal text-center font-display text-2xl font-black text-slate-900 sm:text-4xl"
          >
            {VEIL_LINES[line]}
          </p>
        ) : (
          <>
            <p key={counterLine} className="animate-count-up text-sm font-bold text-emerald-700">
              <span className="animate-pulse-dot me-2 inline-block size-2 rounded-full bg-emerald-600 align-middle" />
              {counterLine}
            </p>

            <div
              ref={lens}
              onPointerDown={onPointerDown}
              onPointerMove={onPointerMove}
              onPointerUp={onPointerUp}
              onPointerCancel={onPointerUp}
              className={[
                "relative mt-4 aspect-square w-full shrink-0 cursor-grab touch-none overflow-hidden rounded-full border border-emerald-200 bg-white/90 shadow-xl transition-[max-width] duration-700 active:cursor-grabbing",
                stage === "found" ? "max-w-[min(58vw,17rem)]" : "max-w-[min(86vw,30rem)]",
              ].join(" ")}
            >
              <svg
                aria-hidden
                viewBox="-100 -100 200 200"
                className="absolute inset-0 h-full w-full"
              >
                <g
                  fill="none"
                  stroke="currentColor"
                  className="text-emerald-500/20"
                  strokeWidth="0.8"
                >
                  {[28, 52, 76, 96].map((r) => (
                    <circle key={r} cx="0" cy="0" r={r} />
                  ))}
                  <path d="M-100 0 H100" />
                  <path d="M0 -100 V100" />
                  <path d="M-71 -71 L71 71" strokeDasharray="3 5" />
                  <path d="M71 -71 L-71 71" strokeDasharray="3 5" />
                </g>
              </svg>

              <span
                aria-hidden
                className="animate-radar-sweep absolute inset-0 origin-center"
                style={{
                  background: "conic-gradient(from 0deg, rgba(22, 163, 74, 0.25), transparent 32%)",
                  opacity: locked ? 0.3 : 0.85,
                  animationDuration: beamDuration,
                  transition: "opacity 700ms ease",
                }}
              />

              {/* thin scanning beam, locked to the same rotation as the sweep */}
              <span
                aria-hidden
                className="animate-radar-sweep absolute inset-0 origin-center will-change-transform"
                style={{ animationDuration: beamDuration }}
              >
                <span
                  className="absolute start-1/2 top-0 h-1/2 w-0.5 -translate-x-1/2 origin-bottom bg-emerald-600/80"
                  style={{
                    opacity: locked ? 0.4 : 1,
                    transition: "opacity 700ms ease",
                  }}
                />
              </span>

              {[0, 1.2, 2.4].map((d) => (
                <span
                  key={d}
                  aria-hidden
                  className="animate-radar-ring absolute inset-0 rounded-full border border-emerald-500/30"
                  style={{
                    animationDelay: `${d}s`,
                  }}
                />
              ))}

              {points.slice(0, visible).map((p, i) => {
                const dim = locked && p.id !== pickId;
                const isPick = p.id === pickId;
                const cat = RADAR_CATEGORIES[p.category];
                const px = 50 + (p.x - offset.x) * 46;
                const py = 50 + (p.y - offset.y) * 46;
                const inside = Math.hypot(px - 50, py - 50) < 47;
                if (!inside) return null;
                return (
                  <button
                    key={p.id}
                    onClick={() => selectPoint(p)}
                    aria-label={p.moment.title}
                    className={[
                      "animate-blip-in group absolute -translate-x-1/2 -translate-y-1/2",
                      "transition-[opacity,transform] duration-700",
                      dim ? "opacity-25 hover:opacity-70" : "opacity-100",
                    ].join(" ")}
                    style={{ left: `${px}%`, top: `${py}%`, animationDelay: `${(i % 6) * 70}ms` }}
                  >
                    <span
                      className={[
                        "relative flex size-7 items-center justify-center will-change-transform",
                        stage === "scan" ? "animate-beam-pass" : "",
                        stage === "focus" && isPick ? "animate-focus-pop" : "",
                      ].join(" ")}
                      style={
                        stage === "scan"
                          ? {
                              animationDuration: beamDuration,
                              animationDelay: `${(p.beamDeg / 360) * (BEAM_MS / 1000) - BEAM_MS / 1000}s`,
                            }
                          : undefined
                      }
                    >
                      {!dim && stage !== "scan" && (
                        <span
                          aria-hidden
                          className="animate-ripple absolute inset-0 rounded-full border border-emerald-500/50"
                          style={{
                            animationDelay: `${(i % 5) * 0.4}s`,
                          }}
                        />
                      )}
                      <span
                        className={[
                          "relative flex size-7 items-center justify-center rounded-full border text-[12px] transition-all duration-300 shadow-2xs",
                          isPick
                            ? "scale-125 border-emerald-600 bg-emerald-100 text-emerald-900"
                            : "border-slate-300 bg-white group-hover:scale-110 group-hover:border-emerald-500",
                        ].join(" ")}
                        style={
                          isPick
                            ? {
                                boxShadow:
                                  "0 0 0 2px rgba(22, 163, 74, 0.4), 0 0 16px 2px rgba(22, 163, 74, 0.3)",
                              }
                            : undefined
                        }
                      >
                        {cat.emoji}
                      </span>
                    </span>
                    <span className="pointer-events-none absolute start-1/2 top-full mt-1 -translate-x-1/2 rounded-md border border-slate-200 bg-white px-2 py-0.5 text-[11px] font-medium whitespace-nowrap text-slate-700 opacity-0 shadow-xs transition-opacity duration-200 group-hover:opacity-100">
                      {cat.label} · {p.moment.district}
                    </span>
                  </button>
                );
              })}

              <span
                aria-hidden
                className="pointer-events-none absolute inset-0 rounded-full"
                style={{
                  boxShadow: "inset 0 0 60px 10px rgba(22, 163, 74, 0.06)",
                }}
              />
            </div>

            <p className="mt-3 text-xs font-medium text-slate-500">
              {stage === "scan"
                ? "نمسح المدينة..."
                : stage === "focus"
                  ? "ثبّتنا على شيء..."
                  : "سحّب الرادار وتنقّل بين النقاط"}
            </p>

            {stage === "found" && picked && (
              <div
                ref={resultRef}
                key={picked.id}
                className="animate-reveal mt-5 w-full max-w-md shrink-0"
              >
                <p className="text-center text-xs font-bold text-emerald-700">لقينا لك حاجة 👀</p>
                <article
                  className="animate-reveal mt-3 rounded-2xl border border-slate-200/90 bg-white p-5 shadow-lg shadow-slate-100"
                  style={{ animationDelay: "160ms" }}
                >
                  <div className="flex items-center justify-between gap-3">
                    <p className="text-xs font-semibold text-slate-600">
                      {RADAR_CATEGORIES[picked.category].emoji}{" "}
                      {RADAR_CATEGORIES[picked.category].label}
                    </p>
                    <p className="rounded-full bg-emerald-50 px-2 py-0.5 text-[11px] font-bold text-emerald-700">
                      {radarStatus(picked.moment)}
                    </p>
                  </div>
                  <h2 className="mt-2 font-display text-xl font-black text-slate-900 sm:text-2xl">
                    {picked.moment.title}
                  </h2>
                  <p className="mt-1 text-sm font-medium text-slate-700">
                    {radarLine(picked.moment)}
                  </p>
                  <p className="mt-2 font-mono text-xs font-bold text-emerald-700">
                    {picked.moment.distanceKm} كم منك · {radarTiming(picked.moment)}
                  </p>
                  <p className="mt-3 text-sm leading-relaxed text-slate-600">
                    {picked.moment.note}
                  </p>
                  <p className="mt-3 text-xs text-slate-400">
                    {picked.moment.place} · {picked.moment.district} · {picked.moment.price} ·{" "}
                    {phaseLabel}
                  </p>
                </article>

                <div className="mt-4 flex flex-wrap items-center gap-3">
                  <button
                    onClick={rescan}
                    className="rounded-full bg-emerald-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-transform duration-300 hover:bg-emerald-700 hover:scale-[1.03] active:scale-[0.97]"
                  >
                    خلّها على الله 🎲
                  </button>
                  <button
                    onClick={rescan}
                    className="rounded-full border border-slate-200 bg-white px-5 py-2.5 text-sm font-semibold text-slate-700 shadow-2xs transition-colors hover:border-slate-300 hover:bg-slate-50"
                  >
                    مو جوي
                  </button>
                  <button
                    onClick={onSeeAll}
                    className="ms-auto text-xs font-bold text-emerald-700 transition-colors hover:text-emerald-800"
                  >
                    شوف كل شيء صاير ←
                  </button>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
