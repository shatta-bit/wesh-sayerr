/**
 * Abstract light city map atmosphere.
 * Clean, subtle architectural background: bright light base, faint street lines,
 * soft block shapes and subtle emerald green accents.
 */
export function CityMapLayer({
  intensity = 1,
  drift = true,
}: {
  /** global opacity multiplier — keep <= 1 so the map stays a backdrop */
  intensity?: number;
  drift?: boolean;
}) {
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
      {/* clean pure white base */}
      <div className="absolute inset-0 bg-white" />

      {/* abstract streets + blocks */}
      <div
        className={["absolute -inset-[12%]", drift ? "animate-drift-slow" : ""].join(" ")}
        style={{ opacity: 0.8 * intensity }}
      >
        <svg
          className="h-full w-full"
          viewBox="0 0 1200 900"
          preserveAspectRatio="xMidYMid slice"
          fill="none"
        >
          {/* building blocks — soft light fills */}
          <g className="fill-slate-900/[0.03]">
            {Array.from({ length: 46 }).map((_, i) => {
              const col = i % 8;
              const row = Math.floor(i / 8);
              const x = 40 + col * 148 + ((i * 37) % 34);
              const y = 30 + row * 150 + ((i * 53) % 40);
              const w = 58 + ((i * 29) % 62);
              const h = 42 + ((i * 41) % 58);
              return <rect key={i} x={x} y={y} width={w} height={h} rx="3" />;
            })}
          </g>

          {/* secondary lanes */}
          <g className="stroke-slate-300/60" strokeWidth="1">
            {Array.from({ length: 9 }).map((_, i) => (
              <path key={`h${i}`} d={`M-20 ${20 + i * 100} H1220`} />
            ))}
            {Array.from({ length: 9 }).map((_, i) => (
              <path key={`v${i}`} d={`M${20 + i * 140} -20 V920`} />
            ))}
          </g>

          {/* main arteries — subtle emerald paths */}
          <g className="stroke-emerald-600/25" strokeWidth="2.2" strokeLinecap="round">
            <path d="M-20 250 C 240 240, 420 300, 700 285 S 1040 250, 1220 300" />
            <path d="M-20 640 C 260 660, 500 600, 780 630 S 1060 690, 1220 640" />
            <path d="M320 -20 C 300 220, 380 480, 340 920" />
            <path d="M880 -20 C 900 260, 830 520, 890 920" />
          </g>

          {/* ring road */}
          <g className="stroke-emerald-600/30" strokeWidth="1.6" strokeDasharray="10 14">
            <ellipse cx="600" cy="450" rx="420" ry="300" />
          </g>
        </svg>
      </div>

      {/* soft atmospheric city glow, breathing very slowly */}
      <div
        className="animate-glow-breathe absolute inset-0"
        style={{ background: "var(--gradient-city-glow)", opacity: 0.6 * intensity }}
      />

      {/* depth: fade the map softly into the white page */}
      <div className="absolute inset-0 bg-radial-fade" />
    </div>
  );
}
