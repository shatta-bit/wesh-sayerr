import { useEffect, useState } from "react";

import { MOODS, buildPlan, type MoodKey, type Plan } from "@/lib/surprise";

const HOURS = [1, 2, 3, 5];
const BUDGETS = [0, 50, 80, 150];
const LINES = ["خلني أشوف وش يناسبك...", "أقرأ نبض المدينة الحين...", "لقيت لك شي 👀"];

export function SurpriseSequence({ citySlug }: { citySlug: string }) {
  const [hours, setHours] = useState(2);
  const [budget, setBudget] = useState(80);
  const [mood, setMood] = useState<MoodKey>("rayeq");
  const [plan, setPlan] = useState<Plan | null>(null);
  const [step, setStep] = useState(-1);

  const rolling = step >= 0 && step < LINES.length;

  useEffect(() => {
    if (step < 0 || step >= LINES.length) return undefined;
    const t = window.setTimeout(() => setStep((s) => s + 1), 700);
    return () => window.clearTimeout(t);
  }, [step]);

  useEffect(() => {
    if (step !== LINES.length) return;
    setPlan(buildPlan({ citySlug, hours, budget, mood }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step]);

  function roll() {
    setPlan(null);
    setStep(0);
  }

  const moodLabel = MOODS.find((x) => x.key === mood)!;

  return (
    <section className="relative w-full min-w-0 max-w-full overflow-hidden rounded-2xl border border-slate-200/90 bg-white p-5 shadow-sm sm:p-8">
      <div className="relative w-full min-w-0">
        <header className="flex w-full min-w-0 flex-wrap items-end justify-between gap-4">
          <div>
            <h2 className="font-display text-xl font-bold text-slate-900 sm:text-2xl">فاجئني 🎲</h2>
            <p className="mt-1 text-sm text-slate-500">
              وقتك، ميزانيتك، ومزاجك — والمدينة ترتب لك الباقي.
            </p>
          </div>
          <button
            onClick={roll}
            disabled={rolling}
            className="rounded-full bg-emerald-600 px-6 py-2.5 text-sm font-bold text-white shadow-sm transition-all duration-200 hover:bg-emerald-700 hover:shadow-md active:scale-[0.97] disabled:opacity-70"
          >
            {rolling ? "لحظة..." : plan ? "فاجئني مرة ثانية 🎲" : "فاجئني 🎲"}
          </button>
        </header>

        <div className="mt-6 grid w-full min-w-0 gap-5 sm:grid-cols-3">
          <Chooser
            label="الوقت المتاح"
            options={HOURS.map((h) => ({
              key: String(h),
              label: h === 1 ? "ساعة" : h === 2 ? "ساعتين" : `${h} ساعات`,
            }))}
            value={String(hours)}
            onChange={(v) => setHours(Number(v))}
          />
          <Chooser
            label="الميزانية"
            options={BUDGETS.map((b) => ({
              key: String(b),
              label: b === 0 ? "ببلاش" : `${b} ر.س`,
            }))}
            value={String(budget)}
            onChange={(v) => setBudget(Number(v))}
          />
          <Chooser
            label="المزاج"
            options={MOODS.map((mm) => ({ key: mm.key, label: `${mm.emoji} ${mm.label}` }))}
            value={mood}
            onChange={(v) => setMood(v as MoodKey)}
          />
        </div>

        {rolling && (
          <p
            key={step}
            className="animate-reveal mt-7 font-display text-lg font-bold text-emerald-700 sm:text-xl"
          >
            {LINES[step]}
          </p>
        )}

        {plan && !rolling && (
          <div className="mt-7 border-t border-slate-100 pt-6">
            <div className="animate-reveal flex flex-wrap items-center gap-2 text-xs font-medium">
              <Chip>عندك {hours === 1 ? "ساعة" : hours === 2 ? "ساعتين" : `${hours} ساعات`}</Chip>
              <Chip>{budget === 0 ? "بدون ميزانية" : `${budget} ريال`}</Chip>
              <Chip>
                مزاج {moodLabel.label} {moodLabel.emoji}
              </Chip>
            </div>

            <ol className="mt-6 space-y-2">
              {plan.steps.map((s, i) => (
                <li
                  key={s.moment.id}
                  className="animate-reveal"
                  style={{ animationDelay: `${i * 220}ms` }}
                >
                  <div className="flex items-start gap-3 rounded-xl border border-slate-100 bg-white p-3.5">
                    <span className="flex size-9 shrink-0 items-center justify-center rounded-full border border-emerald-200 bg-emerald-50 text-base">
                      {s.icon}
                    </span>
                    <div className="min-w-0 pb-1">
                      <p className="text-xs font-bold text-emerald-700">{s.role}</p>
                      <p className="text-base font-bold text-slate-900">{s.moment.title}</p>
                      <p className="mt-0.5 text-xs text-slate-500">
                        {s.moment.place} · {s.moment.district} · {s.moment.price} ·{" "}
                        {s.moment.window}
                      </p>
                    </div>
                  </div>
                  {i < plan.steps.length - 1 && (
                    <span aria-hidden className="my-1 ms-6 block h-4 w-px bg-emerald-400" />
                  )}
                </li>
              ))}
            </ol>

            <p
              className="animate-reveal mt-5 font-mono text-xs text-slate-500"
              style={{ animationDelay: `${plan.steps.length * 220}ms` }}
            >
              {plan.totalHint} · في {plan.city.name}
            </p>
          </div>
        )}
      </div>
    </section>
  );
}

function Chip({ children }: { children: React.ReactNode }) {
  return (
    <span className="rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-800">
      {children}
    </span>
  );
}

function Chooser({
  label,
  options,
  value,
  onChange,
}: {
  label: string;
  options: { key: string; label: string }[];
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div>
      <p className="mb-2 text-xs font-medium text-slate-500">{label}</p>
      <div className="flex flex-wrap gap-1.5">
        {options.map((o) => {
          const active = o.key === value;
          return (
            <button
              key={o.key}
              onClick={() => onChange(o.key)}
              className={[
                "rounded-full border px-3 py-1.5 text-xs font-medium transition-all duration-200 active:scale-95",
                active
                  ? "border-emerald-600 bg-emerald-600 font-bold text-white shadow-2xs"
                  : "border-slate-200 bg-white text-slate-700 hover:border-slate-300 hover:bg-slate-50",
              ].join(" ")}
            >
              {o.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}
