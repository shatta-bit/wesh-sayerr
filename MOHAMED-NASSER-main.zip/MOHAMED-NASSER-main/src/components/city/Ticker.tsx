export function Ticker({ items }: { items: string[] }) {
  const line = [...items, ...items];
  return (
    <div className="relative w-full min-w-0 max-w-full overflow-hidden border-y border-slate-200/80 bg-white py-2.5">
      <div className="animate-ticker flex w-max gap-8 whitespace-nowrap">
        {line.map((t, i) => (
          <span
            key={i}
            className="flex items-center gap-2 font-mono text-xs font-medium text-slate-600"
          >
            <span className="animate-pulse-dot inline-block size-1.5 rounded-full bg-emerald-600" />
            {t}
          </span>
        ))}
      </div>
    </div>
  );
}
