export interface SocialLinksConfig {
  whatsappUrl: string;
  facebookUrl: string;
  instagramUrl: string;
  xUrl: string;
}

/**
 * Social media links configuration for "وش صاير".
 * Easily update URLs here when real account links are ready.
 */
export const socialLinks: SocialLinksConfig = {
  whatsappUrl: "",
  facebookUrl: "",
  instagramUrl: "",
  xUrl: "",
};
