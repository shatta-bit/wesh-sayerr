import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import {
  Calendar,
  Compass,
  Flame,
  Layers,
  MapPin,
  Moon,
  Radio,
  Search,
  ShieldCheck,
  Sparkles,
  Utensils,
  Zap,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";

import { LiveClock, useCityClock } from "@/components/city/LiveClock";
import { LocationDial } from "@/components/city/LocationDial";
import { MomentSheet } from "@/components/city/MomentSheet";
import { PhaseDial } from "@/components/city/PhaseDial";
import { PulseMap } from "@/components/city/PulseMap";
import { PulseRadar } from "@/components/city/PulseRadar";
import { SurpriseSequence } from "@/components/city/SurpriseSequence";
import { Ticker } from "@/components/city/Ticker";
import { Footer } from "@/components/city/Footer";
import { EventImage } from "@/components/city/EventImage";
import {
  CITIES,
  DEFAULT_CITY,
  SECTIONS,
  getCity,
  getMoments,
  type Moment,
  type SectionKey,
} from "@/data/cities";
import { getPhase, phaseFromHour, type PhaseKey } from "@/lib/phases";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "وش صاير حولك؟ — نبض مدينتك الآن" },
      {
        name: "description",
        content:
          "لا تسأل وش تسوي... اسأل وش صاير. اكتشف ما يحدث الآن حولك في المدينة المنورة والرياض وجدة ومكة والدمام.",
      },
      { property: "og:title", content: "وش صاير حولك؟ — نبض مدينتك الآن" },
      {
        property: "og:description",
        content: "تجربة اكتشاف حية: الآن، حولك، الليلة، الناس وين، فعاليات، ونبض المدينة.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const navigate = useNavigate();
  const [citySlug, setCitySlug] = useState(DEFAULT_CITY);
  const city = getCity(citySlug);
  const { hour } = useCityClock();
  const [phase, setPhase] = useState<PhaseKey>("evening");
  const [touched, setTouched] = useState(false);
  const [radar, setRadar] = useState(false);

  // Home page interactive state
  const [mapSection, setMapSection] = useState<SectionKey | "all">("all");
  const [activeTabSection, setActiveTabSection] = useState<SectionKey | "all">("now");
  const [selectedMoment, setSelectedMoment] = useState<Moment | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  const eventsSectionRef = useRef<HTMLElement>(null);
  const surpriseSectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!touched) setPhase(phaseFromHour(hour));
  }, [hour, touched]);

  const p = getPhase(phase);

  const go = (surprise = false) =>
    navigate({ to: "/explore", search: { city: citySlug, surprise: surprise ? 1 : 0, phase } });

  const scrollToEvents = () => {
    eventsSectionRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const scrollToSurprise = () => {
    surpriseSectionRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  // Filtered moments for home page events section
  const cityMoments = useMemo(() => {
    if (activeTabSection === "all") {
      return city.moments;
    }
    return getMoments(city, activeTabSection);
  }, [city, activeTabSection]);

  const filteredMoments = useMemo(() => {
    if (!searchQuery.trim()) return cityMoments;
    const q = searchQuery.toLowerCase().trim();
    return cityMoments.filter(
      (m) =>
        m.title.toLowerCase().includes(q) ||
        m.place.toLowerCase().includes(q) ||
        m.district.toLowerCase().includes(q) ||
        m.tags.some((t) => t.toLowerCase().includes(q)),
    );
  }, [cityMoments, searchQuery]);

  const sectionCounts = useMemo(() => {
    const out = { all: city.moments.length } as Record<SectionKey | "all", number>;
    for (const s of SECTIONS) {
      out[s.key] = getMoments(city, s.key).length;
    }
    return out;
  }, [city]);

  return (
    <div
      data-phase={phase}
      className="relative min-h-screen overflow-x-hidden bg-white text-slate-900"
      style={{ backgroundColor: "#FFFFFF" }}
    >
      {/* ─────────────────────────────────────────────────────────────
          1. HEADER & NAVIGATION
      ─────────────────────────────────────────────────────────────── */}
      <header className="sticky top-0 z-30 border-b border-slate-200/80 bg-white">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-3.5 sm:px-6 lg:px-8">
          {/* Logo & Status */}
          <div className="flex items-center gap-4">
            <Link to="/" className="group flex items-center gap-2.5">
              <div className="flex size-9 items-center justify-center rounded-xl bg-emerald-600 text-white shadow-sm transition-transform duration-200 group-hover:scale-105">
                <Radio className="size-5 animate-pulse" />
              </div>
              <div>
                <span className="font-display text-lg font-black tracking-tight text-slate-950">
                  وش صاير
                </span>
                <span className="ms-1.5 font-mono text-[10px] font-semibold text-emerald-700">
                  LIVE
                </span>
              </div>
            </Link>

            {/* Desktop Navigation Links */}
            <nav className="hidden items-center gap-1 md:flex">
              <span className="h-4 w-px bg-slate-200 mx-2" />
              <button
                onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
                className="rounded-full bg-emerald-50 px-3.5 py-1.5 text-xs font-bold text-emerald-700"
              >
                الرئيسية
              </button>
              <Link
                to="/explore"
                search={{ city: citySlug, surprise: 0, phase }}
                className="rounded-full px-3.5 py-1.5 text-xs font-medium text-slate-600 transition-colors hover:bg-emerald-50 hover:text-emerald-700"
              >
                الخريطة الحية
              </Link>
              <button
                onClick={scrollToEvents}
                className="rounded-full px-3.5 py-1.5 text-xs font-medium text-slate-600 transition-colors hover:bg-emerald-50 hover:text-emerald-700"
              >
                الفعاليات
              </button>
              <button
                onClick={scrollToSurprise}
                className="rounded-full px-3.5 py-1.5 text-xs font-medium text-slate-600 transition-colors hover:bg-emerald-50 hover:text-emerald-700"
              >
                فاجئني 🎲
              </button>
            </nav>
          </div>

          {/* Header Right Actions */}
          <div className="flex items-center gap-2.5">
            <LiveClock className="hidden sm:inline-flex" />
            <PhaseDial
              value={phase}
              onChange={(k) => {
                setTouched(true);
                setPhase(k);
              }}
            />
          </div>
        </div>
      </header>

      {/* ─────────────────────────────────────────────────────────────
          2. HERO SECTION (TWO-COLUMN DESKTOP LAYOUT)
      ─────────────────────────────────────────────────────────────── */}
      <section className="relative mx-auto w-full max-w-7xl px-5 pt-8 pb-12 sm:px-6 lg:px-8 lg:pt-10 lg:pb-14">
        <div className="grid w-full min-w-0 items-center gap-8 lg:grid-cols-12 lg:gap-12">
          {/* Content Column (RTL Start - 6/12) */}
          <div className="w-full min-w-0 lg:col-span-6">
            {/* Live indicator badge */}
            <div
              key={`badge-${phase}-${citySlug}`}
              className="animate-reveal inline-flex max-w-full items-center gap-2 rounded-full border border-emerald-200 bg-emerald-50 px-3.5 py-1.5 text-xs font-bold text-emerald-800 shadow-2xs"
            >
              <span className="animate-pulse-dot inline-block size-2 shrink-0 rounded-full bg-emerald-600" />
              <span>{p.label}</span>
              <span className="text-emerald-400">·</span>
              <span>{city.name}</span>
              <span className="text-emerald-400">·</span>
              <span className="font-mono text-emerald-900">{city.liveCount} شيء صاير</span>
            </div>

            {/* Search & Filter Bar (Moved up directly after live badge) */}
            <div className="mt-4 w-full min-w-0 rounded-2xl border border-slate-200/90 bg-white p-4 sm:p-5 shadow-sm">
              <div className="grid w-full min-w-0 gap-3 sm:grid-cols-12">
                {/* Search Input */}
                <div className="relative min-w-0 sm:col-span-12 md:col-span-5">
                  <Search className="absolute start-3 top-1/2 size-4 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    placeholder="ابحث عن مكان، فعالية، حي، أو تجربة..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 bg-white py-2 pe-3 ps-9 text-xs font-medium text-slate-900 placeholder:text-slate-400 focus:border-emerald-500 focus:bg-white focus:outline-hidden"
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery("")}
                      className="absolute end-2.5 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600"
                    >
                      ✕
                    </button>
                  )}
                </div>

                {/* City Selector in Filter */}
                <div className="min-w-0 sm:col-span-6 md:col-span-3">
                  <select
                    value={citySlug}
                    onChange={(e) => setCitySlug(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 bg-white py-2 px-2.5 text-xs font-medium text-slate-800 focus:border-emerald-500 focus:bg-white focus:outline-hidden"
                  >
                    {CITIES.map((c) => (
                      <option key={c.slug} value={c.slug}>
                        {c.name} ({c.liveCount})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Category Selector in Filter */}
                <div className="min-w-0 sm:col-span-6 md:col-span-2">
                  <select
                    value={activeTabSection}
                    onChange={(e) => setActiveTabSection(e.target.value as SectionKey | "all")}
                    className="w-full rounded-xl border border-slate-200 bg-white py-2 px-2.5 text-xs font-medium text-slate-800 focus:border-emerald-500 focus:bg-white focus:outline-hidden"
                  >
                    <option value="all">كل التصنيفات</option>
                    {SECTIONS.map((s) => (
                      <option key={s.key} value={s.key}>
                        {s.emoji} {s.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Explore Button */}
                <div className="min-w-0 sm:col-span-12 md:col-span-2">
                  <button
                    onClick={() => go(false)}
                    className="w-full rounded-xl bg-emerald-600 py-2 px-3 text-xs font-bold text-white shadow-2xs transition-colors hover:bg-emerald-700"
                  >
                    استكشاف الكل
                  </button>
                </div>
              </div>
            </div>

            {/* Description */}
            <p className="mt-4 text-sm leading-relaxed text-slate-600 sm:text-base">
              لا تسأل وش تسوي... اسأل وش صاير. نبض مدينتك، فعالياتها، وتجاربها الحية في مكان واحد.{" "}
              <span className="font-semibold text-slate-800">{p.hint}.</span>
            </p>

            {/* Action Buttons & Weather */}
            <div className="mt-5 flex w-full min-w-0 flex-wrap items-center gap-3">
              <button
                onClick={() => setRadar(true)}
                className="group flex shrink-0 items-center gap-2 rounded-full bg-emerald-600 px-5 py-2.5 text-xs font-bold text-white shadow-md shadow-emerald-600/20 transition-all duration-200 hover:bg-emerald-700 hover:shadow-lg hover:shadow-emerald-600/30 active:scale-[0.98]"
              >
                <Radio className="size-3.5 animate-pulse" />
                <span>رادار النبض الحي</span>
                <span className="text-xs transition-transform duration-200 group-hover:-translate-x-1">
                  ←
                </span>
              </button>

              <LocationDial value={citySlug} onChange={setCitySlug} />

              <div className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-slate-200 bg-white px-3 py-1.5 font-mono text-xs font-semibold text-slate-600">
                <span>{city.temp}° م</span>
                <span className="text-slate-300">·</span>
                <span>{city.weather}</span>
              </div>
            </div>
          </div>

          {/* Map Column (RTL End - 6/12) */}
          <div className="w-full min-w-0 lg:col-span-6">
            <div className="relative w-full min-w-0 rounded-3xl border border-slate-200/90 bg-white p-3.5 sm:p-4 shadow-xl shadow-slate-200/40">
              {/* Map Header Overlay */}
              <div className="mb-2.5 flex w-full min-w-0 items-center justify-between gap-2 px-1 pt-1">
                <div className="flex min-w-0 items-center gap-2">
                  <span className="animate-pulse-dot inline-block size-2 shrink-0 rounded-full bg-emerald-600" />
                  <span className="truncate text-xs font-bold text-slate-800">
                    خريطة النبض التفاعلية · {city.name}
                  </span>
                </div>
                <Link
                  to="/explore"
                  search={{ city: citySlug, surprise: 0, phase }}
                  className="shrink-0 text-xs font-bold text-emerald-700 transition-colors hover:text-emerald-800"
                >
                  تكبير الخريطة ←
                </Link>
              </div>

              {/* Map Component */}
              <div className="w-full min-w-0 overflow-hidden rounded-2xl">
                <PulseMap
                  city={city}
                  section={mapSection}
                  selectedId={selectedMoment?.id ?? null}
                  onSelect={(m) => setSelectedMoment(m)}
                />
              </div>

              {/* Map Section Quick Filters */}
              <div className="mt-3 flex w-full min-w-0 items-center gap-1.5 overflow-x-auto pb-1 [scrollbar-width:none] [-webkit-overflow-scrolling:touch]">
                <button
                  onClick={() => setMapSection("all")}
                  className={[
                    "shrink-0 rounded-full px-2.5 py-1 text-[11px] font-semibold transition-colors",
                    mapSection === "all"
                      ? "bg-emerald-600 text-white"
                      : "bg-slate-100 text-slate-600 hover:bg-slate-200",
                  ].join(" ")}
                >
                  الكل ({city.moments.length})
                </button>
                {SECTIONS.map((s) => (
                  <button
                    key={s.key}
                    onClick={() => setMapSection(s.key)}
                    className={[
                      "shrink-0 rounded-full px-2.5 py-1 text-[11px] font-semibold transition-colors",
                      mapSection === s.key
                        ? "bg-emerald-600 text-white"
                        : "bg-slate-100 text-slate-600 hover:bg-slate-200",
                    ].join(" ")}
                  >
                    <span className="me-1">{s.emoji}</span>
                    {s.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ─────────────────────────────────────────────────────────────
          3. LIVE MOMENTS / EVENTS SECTION
      ─────────────────────────────────────────────────────────────── */}
      <section
        ref={eventsSectionRef}
        className="mx-auto w-full max-w-7xl min-w-0 px-5 py-10 sm:px-6 lg:px-8 scroll-mt-20"
      >
        <div className="flex w-full min-w-0 flex-wrap items-end justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full bg-emerald-50 px-3 py-1 text-xs font-bold text-emerald-800">
              <Flame className="size-3.5 text-emerald-600" />
              <span>نبض الأماكن الحية</span>
            </div>
            <h2 className="mt-2 font-display text-2xl font-bold text-slate-900 sm:text-3xl">
              أبرز ما يحدث الآن في {city.name}
            </h2>
            <p className="mt-1 text-sm text-slate-500">
              أماكن وتجارب مرتبة حسب الطاقة والحيوية والوقت
            </p>
          </div>

          <Link
            to="/explore"
            search={{ city: citySlug, surprise: 0, phase }}
            className="text-xs font-bold text-emerald-700 transition-colors hover:text-emerald-800"
          >
            عرض جميع نقاط المدينة ({city.moments.length}) ←
          </Link>
        </div>

        {/* Category Filter Rail */}
        <div className="mt-6 flex w-full min-w-0 items-center gap-2 overflow-x-auto pb-2 [scrollbar-width:none] [-webkit-overflow-scrolling:touch]">
          <button
            onClick={() => setActiveTabSection("all")}
            className={[
              "flex shrink-0 items-center gap-1.5 rounded-full px-4 py-2 text-xs font-bold transition-all shadow-2xs",
              activeTabSection === "all"
                ? "bg-emerald-600 text-white"
                : "border border-slate-200 bg-white text-slate-700 hover:bg-slate-50",
            ].join(" ")}
          >
            <span>✨</span>
            <span>الكل</span>
            <span
              className={[
                "rounded-full px-1.5 py-0.2 font-mono text-[11px]",
                activeTabSection === "all"
                  ? "bg-white/20 text-white"
                  : "bg-slate-100 text-slate-600",
              ].join(" ")}
            >
              {sectionCounts.all}
            </span>
          </button>
          {SECTIONS.map((s) => {
            const active = activeTabSection === s.key;
            return (
              <button
                key={s.key}
                onClick={() => setActiveTabSection(s.key)}
                className={[
                  "flex shrink-0 items-center gap-1.5 rounded-full px-4 py-2 text-xs font-bold transition-all shadow-2xs",
                  active
                    ? "bg-emerald-600 text-white"
                    : "border border-slate-200 bg-white text-slate-700 hover:bg-slate-50",
                ].join(" ")}
              >
                <span>{s.emoji}</span>
                <span>{s.label}</span>
                <span
                  className={[
                    "rounded-full px-1.5 py-0.2 font-mono text-[11px]",
                    active ? "bg-white/20 text-white" : "bg-slate-100 text-slate-600",
                  ].join(" ")}
                >
                  {sectionCounts[s.key]}
                </span>
              </button>
            );
          })}
        </div>

        {/* Moments Grid */}
        <div className="mt-6 grid w-full min-w-0 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {filteredMoments.map((m) => (
            <article
              key={m.id}
              onClick={() => setSelectedMoment(m)}
              className="group relative flex w-full min-w-0 cursor-pointer flex-col justify-between overflow-hidden rounded-2xl border border-slate-200/90 bg-white p-4 sm:p-5 shadow-xs transition-all duration-200 hover:-translate-y-0.5 hover:border-emerald-400/80 hover:shadow-md"
            >
              <div>
                {/* Event Photo */}
                <div className="relative mb-3.5 aspect-16/9 w-full overflow-hidden rounded-xl bg-slate-100">
                  <EventImage
                    moment={m}
                    cityName={city.name}
                    className="size-full"
                    imageClassName="size-full object-cover transition-transform duration-300 group-hover:scale-105"
                    alt={m.title}
                  />
                  <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-70" />
                  <div className="pointer-events-none absolute bottom-2.5 inset-x-2.5 flex items-center justify-between gap-2">
                    <span className="rounded-full bg-white/95 px-2.5 py-0.5 text-[11px] font-bold text-slate-900 shadow-xs backdrop-blur-xs">
                      {m.window}
                    </span>
                    <span className="rounded-full bg-emerald-700/95 px-2 py-0.5 font-mono text-[11px] font-bold text-white shadow-xs">
                      طاقة {m.energy}% · {m.crowd}
                    </span>
                  </div>
                </div>

                {/* Title */}
                <h3 className="font-display text-base font-bold text-slate-900 group-hover:text-emerald-700 sm:text-lg">
                  {m.title}
                </h3>

                {/* Metadata */}
                <p className="mt-1.5 text-xs text-slate-500">
                  <span className="font-semibold text-slate-700">{m.place}</span> · {m.district} ·{" "}
                  {m.distanceKm} كم · {m.price}
                </p>

                {/* Note */}
                <p className="mt-2 line-clamp-2 text-xs leading-relaxed text-slate-600">{m.note}</p>
              </div>

              {/* Bottom Tags and Action */}
              <div className="mt-3.5 flex items-center justify-between border-t border-slate-100 pt-2.5">
                <div className="flex flex-wrap gap-1">
                  {m.tags.slice(0, 2).map((t) => (
                    <span
                      key={t}
                      className="rounded-md bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-600"
                    >
                      {t}
                    </span>
                  ))}
                </div>
                <span className="text-xs font-bold text-emerald-700 transition-transform duration-200 group-hover:-translate-x-1">
                  التفاصيل ←
                </span>
              </div>
            </article>
          ))}
        </div>

        {filteredMoments.length === 0 && (
          <div className="mt-8 rounded-2xl border border-slate-200 bg-white p-8 text-center">
            <p className="text-sm font-medium text-slate-600">
              لا توجد نتائج مطابقة لبحثك في هذا التصنيف.
            </p>
            <button
              onClick={() => {
                setSearchQuery("");
                setActiveTabSection("all");
              }}
              className="mt-3 rounded-full bg-emerald-600 px-4 py-1.5 text-xs font-bold text-white"
            >
              إعادة ضبط الفلاتر
            </button>
          </div>
        )}
      </section>

      {/* ─────────────────────────────────────────────────────────────
          5. SURPRISE ME SECTION
      ─────────────────────────────────────────────────────────────── */}
      <section
        ref={surpriseSectionRef}
        className="mx-auto max-w-7xl px-5 py-8 sm:px-6 lg:px-8 scroll-mt-20"
      >
        <SurpriseSequence citySlug={citySlug} />
      </section>

      {/* ─────────────────────────────────────────────────────────────
          6. TRUST / FEATURES STRIP
      ─────────────────────────────────────────────────────────────── */}
      <section className="mx-auto max-w-7xl px-5 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-6 rounded-3xl border border-slate-200/90 bg-white p-6 sm:grid-cols-2 lg:grid-cols-4 lg:p-8">
          <div className="flex items-start gap-3.5">
            <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
              <Zap className="size-5" />
            </div>
            <div>
              <h4 className="font-display text-sm font-bold text-slate-900">تحديث لحظي مستمر</h4>
              <p className="mt-1 text-xs leading-relaxed text-slate-500">
                رصد مباشر لحركة ونبض المدينة على مدار الساعة.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3.5">
            <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
              <MapPin className="size-5" />
            </div>
            <div>
              <h4 className="font-display text-sm font-bold text-slate-900">خريطة تفاعلية ذكية</h4>
              <p className="mt-1 text-xs leading-relaxed text-slate-500">
                استكشف الأماكن والتجارب المحيطة بموقعك بسهولة.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3.5">
            <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
              <Sparkles className="size-5" />
            </div>
            <div>
              <h4 className="font-display text-sm font-bold text-slate-900">تجارب مخصصة</h4>
              <p className="mt-1 text-xs leading-relaxed text-slate-500">
                خطط لطلعتك بضغطة زر حسب وقتك وميزانيتك.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3.5">
            <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
              <ShieldCheck className="size-5" />
            </div>
            <div>
              <h4 className="font-display text-sm font-bold text-slate-900">بيانات موثوقة</h4>
              <p className="mt-1 text-xs leading-relaxed text-slate-500">
                معلومات محلية دقيقة من قلب كل حي سعودي.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ─────────────────────────────────────────────────────────────
          7. TICKER STRIP & FOOTER
      ─────────────────────────────────────────────────────────────── */}
      <div className="mt-6 border-t border-slate-200/80">
        <Ticker items={city.ticker} />
      </div>

      <Footer
        currentCitySlug={citySlug}
        onCitySelect={(slug) => setCitySlug(slug)}
        showCitySwitcher={true}
      />

      {/* ─────────────────────────────────────────────────────────────
          MODALS & SHEETS
      ─────────────────────────────────────────────────────────────── */}
      {selectedMoment && (
        <MomentSheet moment={selectedMoment} onClose={() => setSelectedMoment(null)} />
      )}

      {radar && (
        <PulseRadar
          city={city}
          phaseLabel={p.label}
          onClose={() => setRadar(false)}
          onSeeAll={() => go(false)}
        />
      )}
    </div>
  );
}
