import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";

import { CityBackdrop } from "@/components/city/CityBackdrop";
import { LiveClock, useCityClock } from "@/components/city/LiveClock";
import { LocationDial } from "@/components/city/LocationDial";
import { MomentSheet } from "@/components/city/MomentSheet";
import { PhaseDial } from "@/components/city/PhaseDial";
import { PulseMap } from "@/components/city/PulseMap";
import { SectionRail } from "@/components/city/SectionRail";
import { SurpriseSequence } from "@/components/city/SurpriseSequence";
import { Ticker } from "@/components/city/Ticker";
import { Footer } from "@/components/city/Footer";
import { EventImage } from "@/components/city/EventImage";
import {
  DEFAULT_CITY,
  SECTIONS,
  getCity,
  getMoments,
  type Moment,
  type SectionKey,
} from "@/data/cities";
import { PHASES, getPhase, phaseFromHour, type PhaseKey } from "@/lib/phases";

type ExploreSearch = { city: string; surprise: number; phase?: PhaseKey };

const PHASE_KEYS = PHASES.map((p) => p.key) as string[];

export const Route = createFileRoute("/explore")({
  validateSearch: (search: Record<string, unknown>): ExploreSearch => ({
    city: typeof search["city"] === "string" ? search["city"] : DEFAULT_CITY,
    surprise: search["surprise"] ? 1 : 0,
    ...(typeof search["phase"] === "string" && PHASE_KEYS.includes(search["phase"])
      ? { phase: search["phase"] as PhaseKey }
      : {}),
  }),
  head: () => ({
    meta: [
      { title: "وش صاير الحين — استكشف نبض المدينة" },
      {
        name: "description",
        content:
          "استكشف ما يحدث الآن حولك: الآن، حولك، الليلة، الناس وين؟، فعاليات، ونبض المدينة في خمس مدن سعودية.",
      },
      { property: "og:title", content: "وش صاير الحين — استكشف نبض المدينة" },
      {
        property: "og:description",
        content: "واجهة اكتشاف حية لمدينتك: طاقة الأماكن، أوقاتها، وأسعارها.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Explore,
});

function Explore() {
  const search = Route.useSearch();
  const navigate = useNavigate();
  const { hour } = useCityClock();
  const [citySlug, setCitySlug] = useState(search.city);
  const [section, setSection] = useState<SectionKey>("now");
  const [selected, setSelected] = useState<Moment | null>(null);
  const [phase, setPhase] = useState<PhaseKey>(search.phase ?? "evening");
  const [touched, setTouched] = useState(Boolean(search.phase));
  const surpriseRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!touched) setPhase(phaseFromHour(hour));
  }, [hour, touched]);

  const city = getCity(citySlug);
  const moments = getMoments(city, section);
  const active = SECTIONS.find((s) => s.key === section)!;
  const p = getPhase(phase);

  const counts = useMemo(() => {
    const out = {} as Record<SectionKey, number>;
    for (const s of SECTIONS) out[s.key] = getMoments(city, s.key).length;
    return out;
  }, [city]);

  useEffect(() => {
    if (!search.surprise) return undefined;
    const t = window.setTimeout(
      () => surpriseRef.current?.scrollIntoView({ behavior: "smooth", block: "center" }),
      420,
    );
    return () => window.clearTimeout(t);
  }, [search.surprise]);

  function changeCity(slug: string) {
    setCitySlug(slug);
    setSelected(null);
    navigate({ to: "/explore", search: { city: slug, surprise: 0, phase }, replace: true });
  }

  return (
    <main data-phase={phase} className="relative min-h-screen overflow-x-hidden">
      <div className="pointer-events-none fixed inset-0 opacity-50">
        <CityBackdrop />
      </div>

      <div className="relative">
        <header className="sticky top-0 z-20 w-full border-b border-slate-200/80 bg-white/90 backdrop-blur-md shadow-2xs">
          <div className="mx-auto flex w-full max-w-6xl flex-wrap items-center justify-between gap-3 px-5 py-3.5 sm:px-6 lg:px-8">
            <Link
              to="/"
              className="flex items-center gap-1.5 text-xs font-bold tracking-wide text-emerald-700 transition-colors hover:text-emerald-800"
            >
              <span>←</span>
              <span>وش صاير</span>
            </Link>
            <div className="flex flex-wrap items-center gap-2">
              <LiveClock />
              <PhaseDial
                value={phase}
                onChange={(k) => {
                  setTouched(true);
                  setPhase(k);
                }}
              />
            </div>
          </div>
          <div className="mx-auto w-full max-w-6xl px-5 pb-3.5 sm:px-6 lg:px-8">
            <LocationDial value={citySlug} onChange={changeCity} compact />
          </div>
        </header>

        <Ticker items={city.ticker} />

        <div className="mx-auto w-full max-w-6xl min-w-0 px-5 py-8 sm:px-6 lg:px-8">
          <div className="flex w-full min-w-0 flex-wrap items-end justify-between gap-4">
            <div>
              <p
                key={phase}
                className="animate-reveal inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1 text-xs font-bold text-emerald-800"
              >
                {p.emoji} {p.label}
              </p>
              <h1 className="mt-2 font-display text-3xl font-black text-slate-900 sm:text-4xl">
                {city.name}
              </h1>
            </div>
            <p className="flex items-center gap-2 rounded-full border border-emerald-200 bg-emerald-50/80 px-3.5 py-1.5 text-xs font-bold text-emerald-800">
              <span className="animate-pulse-dot inline-block size-2 rounded-full bg-emerald-600" />
              {city.liveCount} شيء صاير · {city.temp}° {city.weather}
            </p>
          </div>

          <div className="mt-6 w-full min-w-0 overflow-hidden rounded-2xl">
            <PulseMap
              city={city}
              section={section}
              selectedId={selected?.id ?? null}
              onSelect={setSelected}
            />
            <p className="mt-2.5 text-xs font-medium text-slate-500">
              اضغط أي نقطة تشوف وش صاير فيها · {p.hint}
            </p>
          </div>

          <div className="mt-8 w-full min-w-0">
            <SectionRail value={section} onChange={setSection} counts={counts} />
          </div>

          <div key={section} className="animate-reveal mt-6 w-full min-w-0">
            <div className="flex items-baseline gap-3">
              <h2 className="font-display text-xl font-bold text-slate-900 sm:text-2xl">
                <span className="me-2">{active.emoji}</span>
                {active.label}
              </h2>
              <span className="text-sm text-slate-500">{active.hint}</span>
            </div>

            <div className="mt-5 overflow-hidden rounded-2xl border border-slate-200/90 bg-white shadow-sm">
              <ul className="divide-y divide-slate-100">
                {moments.map((mm, i) => (
                  <li key={mm.id}>
                    <button
                      onClick={() => setSelected(mm)}
                      className="group animate-reveal flex w-full items-center gap-3.5 p-3.5 sm:gap-4 sm:p-4 text-start transition-colors duration-200 hover:bg-emerald-50/40"
                      style={{ animationDelay: `${Math.min(i, 8) * 60}ms` }}
                    >
                      <div className="relative size-12 sm:size-14 shrink-0 overflow-hidden rounded-xl bg-slate-100">
                        <EventImage
                          moment={mm}
                          cityName={city.name}
                          className="size-full"
                          imageClassName="size-full object-cover transition-transform duration-200 group-hover:scale-105"
                          showAttribution={false}
                          alt={mm.title}
                        />
                      </div>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-base font-bold text-slate-900 group-hover:text-emerald-700 sm:text-lg">
                          {mm.title}
                        </span>
                        <span className="mt-0.5 block text-xs text-slate-500">
                          {mm.place} · {mm.district} · {mm.distanceKm} كم · {mm.price}
                        </span>
                      </span>
                      <span className="hidden shrink-0 rounded-full bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-600 sm:block">
                        {mm.window}
                      </span>
                      <span className="shrink-0 rounded-full bg-emerald-50 px-2.5 py-1 font-mono text-xs font-bold text-emerald-700 tabular-nums">
                        {mm.energy}% طاقة
                      </span>
                      <span className="shrink-0 text-sm font-bold text-slate-400 transition-transform duration-200 group-hover:-translate-x-1 group-hover:text-emerald-600">
                        ←
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div ref={surpriseRef} className="mt-12 scroll-mt-32">
            <SurpriseSequence citySlug={citySlug} />
          </div>
        </div>

        <div className="mt-16">
          <Footer
            currentCitySlug={citySlug}
            onCitySelect={(slug) => {
              setCitySlug(slug);
              navigate({ to: "/explore", search: { city: slug, surprise: 0 } });
            }}
            showCitySwitcher={true}
          />
        </div>
      </div>

      <MomentSheet moment={selected} onClose={() => setSelected(null)} />
    </main>
  );
}
