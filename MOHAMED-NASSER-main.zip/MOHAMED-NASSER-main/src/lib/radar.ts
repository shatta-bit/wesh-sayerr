/**
 * Radar layer — turns city moments into stable polar positions + categories.
 * Swap `buildRadar()`'s input for a real API response later; the UI only uses
 * the exported types.
 */
import type { City, Moment, SectionKey } from "@/data/cities";

export type RadarCategory = "trend" | "coffee" | "food" | "event" | "sport" | "night" | "shop";

export const RADAR_CATEGORIES: Record<RadarCategory, { emoji: string; label: string }> = {
  trend: { emoji: "🔥", label: "ترند" },
  coffee: { emoji: "☕", label: "قهوة" },
  food: { emoji: "🍔", label: "أكل" },
  event: { emoji: "🎭", label: "فعالية" },
  sport: { emoji: "⚽", label: "رياضة" },
  night: { emoji: "🌙", label: "شيء لليلة" },
  shop: { emoji: "🛍️", label: "تسوق" },
};

const BY_SECTION: Record<SectionKey, RadarCategory> = {
  now: "trend",
  around: "coffee",
  tonight: "night",
  food: "food",
  events: "event",
  pulse: "sport",
};

function hash(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) h = (h ^ s.charCodeAt(i)) * 16777619;
  return Math.abs(h >>> 0);
}

function categoryOf(mm: Moment): RadarCategory {
  const t = mm.tags.join(" ") + " " + mm.title;
  if (/قهوة|كافيه|مقهى|مختصة/.test(t)) return "coffee";
  if (/أكل|مطعم|برجر|عشاء|فطور/.test(t)) return "food";
  if (/تسوق|سوق|أنتيك|حرف/.test(t)) return "shop";
  return BY_SECTION[mm.section];
}

export type RadarPoint = {
  id: string;
  moment: Moment;
  category: RadarCategory;
  /** normalized field coords, roughly -1.6..1.6 (the field is larger than the lens) */
  x: number;
  y: number;
  /** screen angle in degrees, measured clockwise from 12 o'clock — used to sync the scan beam */
  beamDeg: number;
};

/** A short, human-sounding read of the place. */
export function radarLine(mm: Moment): string {
  const crowd =
    mm.crowd === "هادي"
      ? "الجو هادي وما فيه استعجال."
      : mm.crowd === "متوسط"
        ? "الناس بدأت تتجمع هنا."
        : mm.crowd === "زحمة"
          ? "المكان معبأ والحركة واضحة."
          : "هنا أعلى نبض في المدينة الحين.";
  return crowd;
}

/** Live status readout: open/closing + crowd signal. */
export function radarStatus(mm: Moment): string {
  const open = /24|طول الليل/.test(mm.window)
    ? "مفتوح طول الليل"
    : /لين/.test(mm.window)
      ? "مفتوح الآن"
      : "يبدأ قريب";
  return `${open} · ${mm.crowd}`;
}

/** Approximate time to be there. */
export function radarTiming(mm: Moment): string {
  const mins = Math.max(4, Math.round(mm.distanceKm * 2.4));
  return `${mins} دقيقة منك تقريباً · ${mm.window}`;
}

export function buildRadar(city: City): RadarPoint[] {
  return city.moments.map((mm) => {
    const h = hash(mm.id + city.slug);
    const angle = ((h % 3600) / 3600) * Math.PI * 2;
    const radius = 0.28 + (((h >> 12) % 1000) / 1000) * 1.18;
    return {
      id: mm.id,
      moment: mm,
      category: categoryOf(mm),
      x: Math.cos(angle) * radius,
      y: Math.sin(angle) * radius * 0.92,
      beamDeg: ((angle * 180) / Math.PI + 90 + 360) % 360,
    };
  });
}
