export type PhaseKey = "morning" | "afternoon" | "evening" | "latenight";

export type Phase = {
  key: PhaseKey;
  label: string;
  short: string;
  hint: string;
  emoji: string;
};

export const PHASES: Phase[] = [
  {
    key: "morning",
    label: "صباح المدينة",
    short: "صباح",
    hint: "الشوارع لسه تفتح عيونها",
    emoji: "🌅",
  },
  {
    key: "afternoon",
    label: "المدينة تصحصح",
    short: "عصر",
    hint: "الحركة تبدأ تزيد شوي شوي",
    emoji: "🌤",
  },
  {
    key: "evening",
    label: "المدينة بدأت تتحرك",
    short: "مسا",
    hint: "هنا تبدأ الليلة فعليًا",
    emoji: "🌙",
  },
  {
    key: "latenight",
    label: "لسه صاحيين؟",
    short: "آخر الليل",
    hint: "أهدأ ناس وأصدق أماكن",
    emoji: "✨",
  },
];

export function phaseFromHour(hour: number): PhaseKey {
  if (hour >= 5 && hour < 12) return "morning";
  if (hour < 17) return "afternoon";
  if (hour < 23) return "evening";
  return "latenight";
}

export function getPhase(key: PhaseKey): Phase {
  return PHASES.find((p) => p.key === key) ?? PHASES[2]!;
}
