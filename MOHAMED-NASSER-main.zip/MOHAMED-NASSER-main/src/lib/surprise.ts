import { getCity, type City, type Moment, type SectionKey } from "@/data/cities";

export type PlanInput = {
  citySlug: string;
  hours: number;
  budget: number;
  mood: MoodKey;
};

export type MoodKey = "rayeq" | "energy" | "social" | "curious";

export const MOODS: { key: MoodKey; label: string; emoji: string; tags: string[] }[] = [
  { key: "rayeq", label: "رايق", emoji: "🍃", tags: ["هدوء", "قهوة", "مشي", "كتب"] },
  { key: "energy", label: "طاقة", emoji: "⚡", tags: ["كرة", "رياضة", "حفلة", "بادل"] },
  { key: "social", label: "أجتمع", emoji: "🫂", tags: ["زحمة", "سوق", "أكل", "جمهور"] },
  { key: "curious", label: "أستكشف", emoji: "🧭", tags: ["فن", "تراث", "معرض", "تصوير"] },
];

export type PlanStep = {
  icon: string;
  role: string;
  moment: Moment;
};

export type Plan = {
  headline: string;
  city: City;
  steps: PlanStep[];
  totalHint: string;
};

const ROLES: { icon: string; role: string; sections: SectionKey[] }[] = [
  { icon: "📍", role: "نقطة البداية", sections: ["around", "now"] },
  { icon: "☕", role: "التجربة", sections: ["now", "around"] },
  { icon: "🌙", role: "النشاط", sections: ["tonight", "events", "pulse"] },
  { icon: "🍔", role: "الختام", sections: ["food"] },
];

function priceOf(mm: Moment): number {
  const digits = mm.price.replace(/[^\d0-9]/g, "");
  const western = digits.replace(/[0-9]/g, (d) => String("0123456789".indexOf(d)));
  return Number(western || 0);
}

function score(mm: Moment, mood: MoodKey): number {
  const moodTags = MOODS.find((x) => x.key === mood)!.tags;
  const match = mm.tags.filter((t) => moodTags.includes(t)).length;
  return match * 40 + mm.energy + Math.random() * 35;
}

export function buildPlan(input: PlanInput): Plan {
  const city = getCity(input.citySlug);
  const stepCount = input.hours <= 1 ? 2 : input.hours <= 2 ? 3 : 4;
  const perStep = Math.max(10, Math.round(input.budget / stepCount));

  const used = new Set<string>();
  const steps: PlanStep[] = [];

  for (const role of ROLES.slice(0, stepCount === 2 ? 2 : stepCount === 3 ? 3 : 4)) {
    const pool = city.moments
      .filter((mm) => role.sections.includes(mm.section) && !used.has(mm.id))
      .filter((mm) => priceOf(mm) <= perStep * 2);
    const fallback = city.moments.filter((mm) => !used.has(mm.id));
    const list = pool.length ? pool : fallback;
    const pick = [...list].sort((a, b) => score(b, input.mood) - score(a, input.mood))[0];
    if (!pick) continue;
    used.add(pick.id);
    steps.push({ icon: role.icon, role: role.role, moment: pick });
  }

  const moodLabel = MOODS.find((x) => x.key === input.mood)!.label;
  const total = steps.reduce((s, x) => s + priceOf(x.moment), 0);

  return {
    city,
    headline: `عندك ${input.hours === 1 ? "ساعة" : input.hours === 2 ? "ساعتين" : `${input.hours} ساعات`} + ${input.budget} ريال + مزاج ${moodLabel}`,
    steps,
    totalHint: total === 0 ? "كله مجاني تقريبًا" : `تقديريًا ${total} ريال من ${input.budget}`,
  };
}
