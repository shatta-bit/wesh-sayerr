import { useEffect, useState } from "react";
import type { Moment } from "@/data/cities";
import {
  resolvePlacePhoto,
  type ResolvedPlacePhoto,
  VERIFIED_VENUE_PHOTOS,
} from "@/lib/placePhotos";

export function usePlacePhoto(moment: Moment | null | undefined, cityName = "المدينة") {
  const [photo, setPhoto] = useState<ResolvedPlacePhoto | null>(() => {
    if (!moment) return null;
    // Synchronous initial check from verified photos to prevent layout shift
    const verified =
      VERIFIED_VENUE_PHOTOS[moment.place] ||
      Object.entries(VERIFIED_VENUE_PHOTOS).find(
        ([key]) => moment.place.includes(key) || key.includes(moment.place),
      )?.[1];

    if (verified) {
      return {
        url: verified.url,
        source: "verified_location",
        attribution: verified.attribution,
        placeName: moment.place,
        isPlaceholder: false,
      };
    }
    return null;
  });

  const [loading, setLoading] = useState<boolean>(!photo);
  const [error, setError] = useState<boolean>(false);

  useEffect(() => {
    if (!moment) {
      setPhoto(null);
      setLoading(false);
      return;
    }

    let isMounted = true;
    setError(false);

    resolvePlacePhoto(moment, cityName)
      .then((res) => {
        if (isMounted) {
          setPhoto(res);
          setLoading(false);
        }
      })
      .catch((err) => {
        console.warn(`Could not resolve photo for ${moment.place}:`, err);
        if (isMounted) {
          setError(true);
          setLoading(false);
          setPhoto({
            url: null,
            source: "neutral_placeholder",
            placeName: moment.place,
            isPlaceholder: true,
          });
        }
      });

    return () => {
      isMounted = false;
    };
  }, [moment, cityName]);

  return { photo, loading, error };
}
