# What's Happening Now

Build a completely original web experience called "وش صاير حولك؟" (What’s Happening Around You?).

Core concept

This is an experimental Saudi city-discovery website.

The idea is simple:

"لا تسأل وش تسوي... اسأل وش صاير."

Instead of being a normal events directory, the website should make the city feel alive in the current moment. Users explore what is happening around them: things happening now, places with energy, tonight's activities, food, events, sports, and interesting local moments.

This is a design challenge project, NOT a SaaS dashboard and NOT a generic AI landing page.

Target audience

Young people living in or visiting Saudi Arabia who want to discover what is happening around them right now.

Initial cities

Use realistic demo data for:

Riyadh

Jeddah

Madinah

Makkah

Dammam

The first experience should default to Madinah.

Homepage experience

Create an immersive, highly polished Arabic-first homepage.

Hero content:

وش صاير حولك؟

Supporting line:

لا تسأل وش تسوي... اسأل وش صاير.

Show the current city and time prominently.

Primary CTA:

وش صاير؟

Secondary CTA:

فاجئني 🎲

The homepage should immediately communicate that the city is alive and changing.

Main discovery experience

After entering the experience, show an interactive city interface containing:

🔥 الآن
Things happening right now.

📍 حولك
Interesting nearby places and experiences.

🌙 الليلة
Things worth doing tonight.

🍔 الناس وين؟
Popular food and social spots.

🎭 فعاليات
Events and experiences.

⚽ نبض المدينة
Sports, trends and local activity.

Use realistic fictional/demo content. Clearly structure the data so it can later be replaced by a real API.

Surprise feature

Create a prominent interactive button:

فاجئني 🎲

When clicked, generate a playful mini-plan based on:

available time

budget

mood

city

Example:

"عندك ساعتين + 80 ريال + مزاج رايق"

Then create a visual journey such as:

📍 Location → ☕ Experience → 🌙 Activity → 🍔 Finish

This should feel like a delightful discovery rather than a boring recommendation list.

Visual direction

Do NOT use generic AI website aesthetics.

Avoid:

purple AI gradients

excessive glassmorphism

generic SaaS cards

generic dashboard layouts

robot/AI imagery

stock-photo-heavy design

template-like hero sections

Instead create an original visual language inspired subtly by modern Saudi urban life.

Think:

contemporary Saudi editorial design

city maps

street signage

wayfinding systems

modern Arabic typography

subtle urban textures

night-city atmosphere

dynamic information

playful micro-interactions

Saudi identity should feel authentic and sophisticated, NOT cliché.

Do not rely on obvious symbols such as palm trees, flags, or stereotypical desert imagery.

Interaction design

The website should feel alive.

Include:

subtle animated city/map elements

smooth transitions

hover states

changing activity indicators

animated time/status elements

elegant page transitions

micro-interactions on buttons

subtle movement when switching between city sections

Animations should feel intentional and premium, not excessive.

Responsive design

Design mobile-first because the final website will be viewed heavily on phones.

It must look excellent on:

mobile

tablet

desktop

The mobile experience should NOT simply be a compressed desktop layout.

Technical direction

Build this as a polished frontend prototype with clean reusable components.

Use mock data for now.

Structure the project so real APIs can be connected later.

Prioritize:

visual identity

interaction quality

typography

responsive behavior

performance

clean component architecture

Do not add authentication, payments, admin dashboards, or unnecessary backend functionality in this first version.

The goal is a memorable, award-worthy web experience for the Made in Framer AI Website Challenge.

Make the result feel designed by a creative human designer, not generated from a standard AI website template.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://live-saudi-vibes.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/08c25e7b-df1b-4d90-bc20-9eb1e24d8380).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
