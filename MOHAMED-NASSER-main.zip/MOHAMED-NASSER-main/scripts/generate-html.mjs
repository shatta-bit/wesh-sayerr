import fs from "node:fs";
import path from "node:path";

const distDir = path.resolve(process.cwd(), "dist");
const outputPublicDir = path.resolve(process.cwd(), ".output/public");
const assetsDir = path.join(outputPublicDir, "assets");

if (!fs.existsSync(assetsDir)) {
  console.error("Assets directory not found at:", assetsDir);
  process.exit(1);
}

const files = fs.readdirSync(assetsDir);
// Find the newest index-*.js and styles-*.css files
const jsFiles = files.filter((f) => f.startsWith("index-") && f.endsWith(".js"));
const cssFiles = files.filter((f) => f.startsWith("styles-") && f.endsWith(".css"));

if (jsFiles.length === 0) {
  console.error("Could not find index-*.js in assets directory");
  process.exit(1);
}

// Sort by mtime to ensure we get the latest built asset
const getLatest = (fileList) =>
  fileList
    .map((f) => ({ name: f, time: fs.statSync(path.join(assetsDir, f)).mtimeMs }))
    .sort((a, b) => b.time - a.time)[0].name;

const jsFile = getLatest(jsFiles);
const cssFile = cssFiles.length > 0 ? getLatest(cssFiles) : null;

const cssLink = cssFile ? `\n    <link rel="stylesheet" href="/assets/${cssFile}" />` : "";

const htmlContent = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>وش صاير حولك؟ — نبض مدينتك الآن</title>
    <meta name="description" content="لا تسأل وش تسوي... اسأل وش صاير. اكتشف نبض مدينتك السعودية في هذه اللحظة." />
    <meta property="og:title" content="وش صاير حولك؟ — نبض مدينتك الآن" />
    <meta property="og:description" content="تجربة اكتشاف حية لمدن السعودية: الآن، حولك، الليلة." />
    <meta property="og:type" content="website" />
    <meta name="twitter:card" content="summary_large_image" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800;900&family=IBM+Plex+Sans+Arabic:wght@300;400;500;600;700;800&family=Noto+Kufi+Arabic:wght@400;600;700;800&family=IBM+Plex+Mono:wght@400;500;600&display=swap" />${cssLink}
    <link rel="icon" href="/favicon.ico" type="image/x-icon" />
    <script>
      window.$_TSR = window.$_TSR || {
        router: { matches: [] },
        h: function () {},
        e: function () {},
        c: function () {},
        p: function (cb) { if (typeof cb === 'function') cb(); },
        buffer: []
      };
    </script>
  </head>
  <body>
    <script type="module" src="/assets/${jsFile}"></script>
  </body>
</html>
`;

// Write to dist/index.html and fallback files for SPA route support
fs.writeFileSync(path.join(distDir, "index.html"), htmlContent, "utf8");
fs.writeFileSync(path.join(distDir, "200.html"), htmlContent, "utf8");
fs.writeFileSync(path.join(distDir, "404.html"), htmlContent, "utf8");

// Support direct access to /explore
const exploreDir = path.join(distDir, "explore");
if (!fs.existsSync(exploreDir)) {
  fs.mkdirSync(exploreDir, { recursive: true });
}
fs.writeFileSync(path.join(exploreDir, "index.html"), htmlContent, "utf8");
fs.writeFileSync(path.join(distDir, "explore.html"), htmlContent, "utf8");

console.log("Successfully generated SPA HTML entrypoints with:", { jsFile, cssFile });
